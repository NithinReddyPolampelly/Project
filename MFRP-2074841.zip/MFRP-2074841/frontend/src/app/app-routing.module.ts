import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddpizzaComponent } from './Adminhome/addpizza/addpizza.component';
import { AdminComponent } from './Adminhome/admin/admin.component';
import { EditComponent } from './Adminhome/edit/edit.component';
import { FeedbackComponent } from './Adminhome/feedback/feedback.component';
import { VieworderComponent } from './Adminhome/vieworder/vieworder.component';
import { ViewpizzaComponent } from './Adminhome/viewpizza/viewpizza.component';
import { ViewuserComponent } from './Adminhome/viewuser/viewuser.component';
import { AuthGuard } from './auth/auth.guard';
import { AdminGuard } from './auth/admin.guard';

import { MainComponent } from './ind/main/main.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CartComponent } from './user/cart/cart.component';
import { EditProfileComponent } from './user/edit-profile/edit-profile.component';
import { SendFbComponent } from './user/send-fb/send-fb.component';
import { UserhomeComponent } from './user/userhome/userhome.component';
import { EmpCartComponent } from './user/emp-cart/emp-cart.component';


const routes: Routes = [
  { path: '', component: MainComponent },
  {path:'login', component:LoginComponent},
   { path: 'register', component: RegisterComponent },
   { path: 'admin', component:AdminComponent,canActivate:[AdminGuard]},
   { path: 'admin/addpizza', component:AddpizzaComponent,canActivate:[AdminGuard] },
   { path: 'admin/editpizza', component:EditComponent ,canActivate:[AdminGuard]},
   { path: 'admin/viewpizza', component:ViewpizzaComponent,canActivate:[AdminGuard]},
   { path: 'admin/userhome', component:UserhomeComponent,canActivate:[AdminGuard]},
   { path: 'admin/feedback', component: FeedbackComponent,canActivate:[AdminGuard] },
   { path: 'admin/viewuser', component: ViewuserComponent,canActivate:[AdminGuard]},
   { path: 'admin/vieworder', component: VieworderComponent,canActivate:[AdminGuard]},

   { path: 'user', component: UserhomeComponent,canActivate:[AuthGuard]},
   { path: 'user/profile', component:EditProfileComponent,canActivate:[AuthGuard]},
   { path: 'user/feedback', component: SendFbComponent,canActivate:[AuthGuard]},
   { path: 'user/cart', component: CartComponent,canActivate:[AuthGuard]},
   { path: 'user/empcart', component: EmpCartComponent,canActivate:[AuthGuard]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
