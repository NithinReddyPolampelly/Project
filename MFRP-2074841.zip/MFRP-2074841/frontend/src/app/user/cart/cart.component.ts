import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminComponent } from 'src/app/Adminhome/admin/admin.component';
import { AdminService } from 'src/app/services/admin.service';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  total:any=0;
  pizzas:any;
  id=localStorage.getItem('id');
  public data={
    whichuser:'',
    pizza:'',
     total:0
  }
  constructor(private service:CartService,private router:Router) { }

  ngOnInit(): void {
    this.service.getcart(this.id).subscribe(data=>{
      this.pizzas=data;
      console.log(data);
      
      for (var val of this.pizzas) {
        this.total=this.total+val.pizzaprice;
       }
          //  this.router.navigate(['/user/empcart']);
          if(this.total==0){
            this.router.navigate(['/user/empcart']);
       } 

    } )
    
  }
 
deletefromcart(f:any){
  this.service.delcartitem(f._id).subscribe(data=>console.log(data));
  alert("item is removed from cart");
  this.total=0;
  this.ngOnInit();
}

checkout(){
 
  this.data.total=this.total;
  if(this.id==null){
    this.id='';
  }
  this.data.whichuser=this.id;
  this.data.pizza=this.pizzas;
  console.log(this.data);
   this.service.addorder(this.data).subscribe(data=>console.log(data));
   this.service.delcart(this.data.whichuser).subscribe();
   alert("order has been placed");
   this.total=0;
   this.ngOnInit();
}
}
