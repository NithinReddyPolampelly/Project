import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-cart',
  templateUrl: './emp-cart.component.html',
  styleUrls: ['./emp-cart.component.css']
})
export class EmpCartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
