import { Component, OnInit } from '@angular/core';
import { RouteConfigLoadStart, Router } from '@angular/router';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-send-fb',
  templateUrl: './send-fb.component.html',
  styleUrls: ['./send-fb.component.css']
})
export class SendFbComponent implements OnInit {

  constructor(private service:CartService,private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(f:any){
    this.service.postfb(f).subscribe(data=>console.log(data));
    alert('feedback submitted');
    this.router.navigate(['/user']);
  }
}
