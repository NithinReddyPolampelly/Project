import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendFbComponent } from './send-fb.component';

describe('SendFbComponent', () => {
  let component: SendFbComponent;
  let fixture: ComponentFixture<SendFbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SendFbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SendFbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
});
