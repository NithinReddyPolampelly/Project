import { Component, ComponentFactoryResolver, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  public nname: any;
  public nemail: any;
  public ncontact: any;
  public user:any;
  public id=localStorage.getItem('id');
  public data={
   _id:this.id,
   name:'',
   email:'',
   contact:'',
   password:''
  }
  
  constructor(private service:AuthService , private router:Router) { this.service.getdatabyid(this.id).subscribe(data=>{this.user=data;console.log(data);})}

  ngOnInit(): void {
  }
  change(){
     this.data.name=this.nname;
     this.data.email=this.nemail;
     this.data.contact=this.ncontact;
     this.data.password=this.user.password;
     this.service.editprofile(this.data,this.id).subscribe((data)=>console.log(data));
     alert('profile updated');
     this.router.navigate(['/user']);
  }

}
