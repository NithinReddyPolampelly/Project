import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {
  pizzas:any;
  id=localStorage.getItem('id');
  public data={
   userid:this.id,
   pizzaname:'',
   pizzasize:'',
   pizzaprice:'',
   pizzaimage:''
  }
  msg:any;
 
  constructor( private cartservice:CartService ,private service:AdminService) { this.service.getpizza().subscribe(data=>this.pizzas=data)}

  ngOnInit(): void {
  }
  addtocart(pizza:any) {
    this.data.pizzaname=pizza.pizzaname;
    this.data.pizzasize=pizza.pizzasize;
    this.data.pizzaprice=pizza.pizzaprice;
    this.data.pizzaimage=pizza.pizzaimage;
    this.cartservice.addcart(this.data).subscribe(data=>console.log(data) )
    alert('item is added to cart');
    console.log(pizza);

  }

}
