import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Feedback } from '../feedback';
import { Pizza } from '../pizza';


@Injectable({
  providedIn: 'root'
})
export class CartService {

constructor(private http: HttpClient, private router: Router) { }
addcart(data:any){
  return this.http.post('http://localhost:8081/api/addcart',data)
}
getcart(id:any){
  return this.http.get('http://localhost:8081/api/getcart'+'/'+id)
 }
 delcartitem(id:any){
  return this.http.delete('http://localhost:8081/api/delcart'+'/'+id);
}
delcart(id:any){
  return this.http.delete('http://localhost:8081/api/delcarts'+'/'+id);
}
postfb(data:any){
  return this.http.post('http://localhost:8081/api/postfb',data)
}
getfb():Observable<Feedback[]>{
  return this.http.get<Feedback[]>('http://localhost:8081/api/getfb')
 }
 delfb(id:any){
  return this.http.delete<Feedback[]>('http://localhost:8081/api/delfb'+'/'+id);
}
addorder(data:any){
  return this.http.post('http://localhost:8081/api/addorder',data)
}
getorder(){
  return this.http.get('http://localhost:8081/api/getorder')
 }
 delorder(id:any){
  return this.http.delete('http://localhost:8081/api/delorder'+'/'+id);
}
getorderbyid(id:any){
  return this.http.get('http://localhost:8081/api/getorderbyid'+'/'+id)
 }
}
