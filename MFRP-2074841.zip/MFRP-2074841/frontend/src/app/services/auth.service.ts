import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../user';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
 
  public viewuser:any;
  public userlogin:boolean=false;
  public adminlogin:boolean=false;
  saveProduct(data: any):Observable<User[]>{
    return this.http.post<User[]>('http://localhost:8081/api/register',data)
   }
   getdata():Observable<User[]>{
    return this.http.get<User[]>('http://localhost:8081/api/getuser')
   }
   getdataid(id:any):Observable<User[]>{
    return this.http.get<User[]>('http://localhost:8081/api/getuser'+'/'+id);
   }
   getdatabyid(id:any):Observable<User[]>{
    return this.http.get<User[]>('http://localhost:8081/api/viewuser'+'/'+id);
   }
   editprofile(data:any,id:any): Observable<User[]> {
    return this.http.put<User[]>('http://localhost:8081/api/editprofile'+'/'+id, data);
  }
 

 
  constructor(private http: HttpClient) { }
// // if present then true otherwise false
  userloggedIn() {
    console.log(this.userlogin)
    return this.userlogin;
  }
  adminloggedIn(){
    return this.adminlogin;
  }

  getToken() {
    return localStorage.getItem('token')
  }

}