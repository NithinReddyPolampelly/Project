import { TestBed } from '@angular/core/testing';
import {
    HttpClientTestingModule,
    HttpTestingController
  } from "@angular/common/http/testing";
import { AuthService } from './auth.service';
import { User } from '../user';

describe('AuthService', () => {
  let service: AuthService;
  let httptestingcontroller:HttpTestingController;
  const email='navaneetha@gmail.com';
  const baseUrl='http://localhost:8081/api/getuser/navaneetha@gmail.com';
  const baseUrlpost='http://localhost:8081/api/postuser'
  let user:User;
 
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule],
      providers:[AuthService]
    });
    httptestingcontroller=TestBed.get(HttpTestingController);
    const user={
      _id: "621f088e9a907d2440f8f1db",
      name:'navaneetha',
      email:'navaneetha@gmail.com',
      contact:9966776679,
     password:'Navaneetha@123'
    }
    service = TestBed.get(AuthService);
  });
  it("should return data", () => {
   
 let result:User[];
    service.getdataid(email).subscribe(t => {
      expect(t).toEqual([user]);
    });
    const req = httptestingcontroller.expectOne({
      method: "GET",
      url: baseUrl
    });
   
    req.flush([user]);
    
  });
  it("should call POST API to create a new traveller", () => {
    service.saveProduct(user).subscribe();
   
    let req =httptestingcontroller.expectOne({ method: "POST", url: baseUrlpost });
    // req.flush(req);
    // expect(req.request.body).toEqual(user);
  });
});

