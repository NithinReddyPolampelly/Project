import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Pizza } from '../pizza';
@Injectable({
  providedIn: 'root'
})
export class AdminService {
  public temp:any;
  public id:any;
  public avail:boolean = false;
  public msg:string="";
  constructor(private http: HttpClient) { }
  addpizza(data: any):Observable<Pizza[]>{
    return this.http.post<Pizza[]>('http://localhost:8081/api/addpizza',data,)
   }
   getpizza():Observable<Pizza[]>{
    return this.http.get<Pizza[]>('http://localhost:8081/api/getpizza',)
   }
   deletepizza(id:any){
    return this.http.delete<Pizza[]>('http://localhost:8081/api/deletepizza'+'/'+id);
  }
  editpizza(data:any,id:any): Observable<Pizza[]> {
    return this.http.put<Pizza[]>('http://localhost:8081/api/editpizza'+'/'+id, data);
  }
  getpizzaid(id:any):Observable<Pizza[]>{
    return this.http.get<Pizza[]>('http://localhost:8081/api/getpizza'+'/'+id);
  }
  getToken() {
    return localStorage.getItem('token')
  }
}
