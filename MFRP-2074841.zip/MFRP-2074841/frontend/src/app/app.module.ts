import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './ind/main/main.component';
import { HttpClientModule ,HTTP_INTERCEPTORS} from '@angular/common/http';
import { HeaderComponent } from './ind/header/header.component';
import { FamousComponent } from './ind/famous/famous.component';
import { ChefsComponent } from './ind/chefs/chefs.component';
import { FormsModule } from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';

import { TokenInterceptorService } from './services/token-interceptor.service';

import { AdminNavComponent } from './Adminhome/admin-nav/admin-nav.component';
import { ViewpizzaComponent } from './Adminhome/viewpizza/viewpizza.component';
import { AddpizzaComponent } from './Adminhome/addpizza/addpizza.component';
import { AdminComponent } from './Adminhome/admin/admin.component';
import { EditComponent } from './Adminhome/edit/edit.component';
import { FeedbackComponent } from './Adminhome/feedback/feedback.component';
import { UserhomeComponent } from './user/userhome/userhome.component';
import { UserNavComponent } from './user/user-nav/user-nav.component';
import { EditProfileComponent } from './user/edit-profile/edit-profile.component';
import { CartComponent } from './user/cart/cart.component';
import { SendFbComponent } from './user/send-fb/send-fb.component';
import { ViewuserComponent } from './Adminhome/viewuser/viewuser.component';
import { VieworderComponent } from './Adminhome/vieworder/vieworder.component';
import { EmpCartComponent } from './user/emp-cart/emp-cart.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AdminGuard } from './auth/admin.guard';
import { AuthGuard } from './auth/auth.guard';

// import { Login1Component } from './auth/login1/login1.component';
// import { AddpizzaComponent } from './admin/addpizza/addpizza.component';
// import { AdminhomeComponent } from './admin/adminhome/adminhome.component';
// import { EditpizzaComponent } from './admin/editpizza/editpizza.component';
// import { IndComponent } from './admin/ind/ind.component';
// import { ViewfeedbackComponent } from './admin/viewfeedback/viewfeedback.component';
// import { ViewoneorderComponent } from './admin/viewoneorder/viewoneorder.component';
// import { ViewoneuserComponent } from './admin/viewoneuser/viewoneuser.component';
// import { ViewpizzaComponent } from './admin/viewpizza/viewpizza.component';
// import { ViewuserComponent } from './admin/viewuser/viewuser.component';

@NgModule({
  declarations: [
    AppComponent,
     MainComponent,
     HeaderComponent,
     FamousComponent,
     ChefsComponent,
     RegisterComponent,
     LoginComponent,
     AddpizzaComponent,
     UserhomeComponent,
     AdminComponent,
     AddpizzaComponent,
     AdminNavComponent,
     ViewpizzaComponent,
     EditComponent,
     FeedbackComponent,
     UserNavComponent,
     EditProfileComponent,
     CartComponent,
     SendFbComponent,
     ViewuserComponent,
     VieworderComponent,
     EmpCartComponent
  // AddpizzaComponent,
  // AdminhomeComponent,
  // EditpizzaComponent,
  // IndComponent,
  // ViewfeedbackComponent,
  // ViewoneorderComponent,
  // ViewoneuserComponent,
  // ViewpizzaComponent,
  // ViewuserComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule

  ],
  providers: [AuthGuard,AdminGuard,{
    provide:HTTP_INTERCEPTORS,
    useClass:TokenInterceptorService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
