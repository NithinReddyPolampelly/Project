import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
   msg: any = [];
  arr: any[]=[];
  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    this.readUser()
  }
  readUser() {
    this.authService.getdata().subscribe(
      data => {
        this.arr = data;
      },
      error => {
        console.log(error);
      }
    )
  }
  onSubmit(f:any) {
   
    for (var val of this.arr) {
      var a = val['email'];
      var b = f.email;
      if (a == b) {
        this.msg = "User already exist with this user name (email)!!";
      
        return;
      }
    }

    if (f.password != f.password1) {
      this.msg = "Password   doesn't match";

      return;
    }

    this.authService.saveProduct(f).subscribe((result)=>{
      console.log(result); });
    this.router.navigate(['/login']);
   
  }
  
}
