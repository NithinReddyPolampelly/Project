export interface Feedback {
 _id:string,
 name:string,
 email:string,
 msg:string
 }