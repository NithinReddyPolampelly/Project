import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {
  public name: any;
  public email: any;
  public contact: any;
 user:any;
  constructor(private service:AuthService) { this.service.getdatabyid(this.service.viewuser).subscribe(data=>{
    console.log(data);
    this.user=data;
    this.name=this.user.name;
    this.email=this.user.email;
    this.contact=this.user.contact;
  
  }
    )}

  ngOnInit(): void {
  
  }

}
