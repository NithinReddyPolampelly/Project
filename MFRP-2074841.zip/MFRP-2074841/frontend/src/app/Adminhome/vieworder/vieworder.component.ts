import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-vieworder',
  templateUrl: './vieworder.component.html',
  styleUrls: ['./vieworder.component.css']
})
export class VieworderComponent implements OnInit {
  total:any=0;
  pizzas:any;
  pizza:any;
  // datas:any;
  constructor(private service:AuthService,private cartservice:CartService) { 
    
    this.cartservice.getorderbyid(this.service.viewuser).subscribe(data=>{this.pizzas=data;
      this.pizza=this.pizzas[0].pizza;
      for (var val of this.pizza) {
        this.total=this.total+val.pizzaprice;
           }
    console.log(this.pizzas[0].pizza)})
  }

  ngOnInit(): void {
  }

}
