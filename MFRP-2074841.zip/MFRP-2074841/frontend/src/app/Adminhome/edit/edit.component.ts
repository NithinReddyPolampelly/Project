import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  onepizza:any;
image:any;
  ngOnInit(): void {
    this.onepizza = this.service.temp;
  }
  constructor( private service:AdminService, private route:ActivatedRoute , private router:Router) { }
  onSubmit(data:any){
    console.log(data);
    data._id=this.onepizza._id;
    this.service.editpizza(data,this.onepizza._id).subscribe();
    alert("pizza edited");
    this.router.navigate(['/admin/viewpizza']); 
  }
 
  selectImage(event:any) {
    console.log("image selected");
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.image = file;
    }
  }
}
