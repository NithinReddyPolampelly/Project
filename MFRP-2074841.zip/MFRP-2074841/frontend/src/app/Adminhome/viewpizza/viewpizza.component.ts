import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Pizza } from 'src/app/pizza';
import { AdminService } from 'src/app/services/admin.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-viewpizza',
  templateUrl: './viewpizza.component.html',
  styleUrls: ['./viewpizza.component.css']
})
export class ViewpizzaComponent implements OnInit {

  constructor(private service:AdminService , private router:Router) { }
public pizzas:Pizza[]=[];
  ngOnInit(): void {
    this.service.getpizza().subscribe((data)=>this.pizzas=data);
  }

  deletepizza(pizza:any) {
    var pizzaid = pizza._id;
    this.service.deletepizza(pizzaid).subscribe(
      data => {
        alert("succesfully deleted pizza");
      this.ngOnInit();
      }
    )
  }
  editpizza(pizza:any) {
    this.service.temp = pizza;
    // console.log("hi"+this.service.temp.pizzaname);
    this.router.navigate(['/admin/editpizza']);
  }

}
