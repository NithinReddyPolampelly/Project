import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/services/admin.service';
import { AuthService } from 'src/app/services/auth.service';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  orders : any =[];
  constructor(private router:Router,private service:CartService,private authservice:AuthService) { }

  ngOnInit(): void {
    this.service.getorder().subscribe(data=>this.orders=data);
  }
  delete(data:any){
   this.service.delorder(data).subscribe();
    alert("order deleted");
    this.ngOnInit();
  }
  seeorder(data:any){
    this.authservice.viewuser=data.whichuser;
    this.router.navigate(['/admin/vieworder']);
  }
  viewuser(data:any){
     this.authservice.viewuser=data.whichuser;
     this.router.navigate(['/admin/viewuser']);
  }
 
}
