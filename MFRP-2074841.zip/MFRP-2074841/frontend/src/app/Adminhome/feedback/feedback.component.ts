import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/services/cart.service';
import { CartComponent } from 'src/app/user/cart/cart.component';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
 public arr:any[]=[];
  constructor(private service:CartService) {}

  ngOnInit(): void {
    this.service.getfb().subscribe(data=>this.arr=data)
  }
delete(f:any){
  this.service.delfb(f).subscribe(data=>console.log(f));
  alert("feedback deleted");
  this.ngOnInit();
}
}
