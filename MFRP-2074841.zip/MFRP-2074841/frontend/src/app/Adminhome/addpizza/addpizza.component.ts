import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-addpizza',
  templateUrl: './addpizza.component.html',
  styleUrls: ['./addpizza.component.css']
})
export class AddpizzaComponent implements OnInit {
 image:any;
  constructor( private service:AdminService,private router:Router) { }

  ngOnInit(): void {
  }
  
  onSubmit(f:any){
    this.service.addpizza(f).subscribe((result)=>{console.log(result); });
    alert("pizza added");
    this.router.navigate(['/admin/viewpizza'])

  }

  selectImage(event:any) {
    console.log("image selected");
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.image = file;
    }
  }
   
}
