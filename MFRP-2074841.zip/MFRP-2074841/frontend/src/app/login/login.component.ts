import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private authService: AuthService) { }
  public isAdmin: boolean = false;
  arr: any;
  msg: string = '';
  id: string = '';
  ngOnInit(): void {
    this.readUser();
  }
  readUser() {
    this.authService.getdata().subscribe(
      data => {
        this.arr = data;
      },
      error => {
        console.log(error);
      }
    )
  }


  onSubmit(f: any) {
    this.authService.getdataid(f.email).subscribe(data => {
      this.arr = data;
      if (this.arr == null) {
        this.msg = 'Dont have an account with this email id. Please register first';
      }
      else {
        if (this.arr['email'] == f.email && this.arr['password'] == f.password) {
         this.id = this.arr['_id'];
          if (this.arr['role'] == "admin")
            this.isAdmin = true;
          if (this.isAdmin) {
            console.log("in admin");
            this.authService.adminlogin = true;
            this.router.navigate(['/admin']);
          }
          else {
            console.log("in customer");
            this.authService.userlogin = true;
            
            localStorage.setItem('email', f.email);
            localStorage.setItem('id', this.id);
            this.router.navigate(['/user']);
          }
        }
        else {
          this.msg = "Password is incorrect";
        }
      }
    })
  }
}
