export interface User {
   _id: string;
   name:string;
   email:string;
   contact:Number;
  password:string;
   // role:string;
   // blocked:boolean;
}
