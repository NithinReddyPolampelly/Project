export interface Pizza {
   _id:string;
 pizzaname:string;
   pizzasize:string;
  pizzaprice:Number;
  pizzaimage:string;
}
