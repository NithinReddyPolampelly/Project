const express = require('express')
const router = express.Router()
// require('./routes/standup')(router)
// module.exports=router
const user = require('../models/user')
const pizza = require('../models/pizza')
const feedback = require('../models/feedback')
const cart = require('../models/cart')
const order = require('../models/order')
const jwt = require('jsonwebtoken')
const bcrypt=require('bcrypt');
//user details
router.get('/getuser', function (req, res) {
    user.find({}, (err, user) => {
        if (err) {
            res.json({ success: false, message: err });
        } else {
            if (!user) {
                res.json({ success: false, message: 'No user found.' });
            } else {
                res.json(user);
            }
        }
    })
})
router.post('/register', function (req, res) {
    let note = new user(req.body)
    note.save(function (err, note) {
        if (err) {
            return res.status(400).json(err)
        }
        res.status(200).json(note)
    })
})
router.put('/editprofile/:id',(req, res) => {
    if (!req.params.id) {
        res.json({ success: false, message: 'No user id provided' });
    } else {
        user.findOne({ _id: req.body._id }, (err, user) => {
            if (err) {
                res.json({ success: false, message: 'Not a valid user id' });
            } else {
                user.name = req.body.name;
                user.email = req.body.email;
                user.contact = req.body.contact;
                user.password = req.body.password;
                user.save((err) => {
                    if (err) {
                        res.json({ success: false, message: err });
                    } else {
                        res.json({ success: true, message: 'profile Updated' });
                    }
                });
            }
        });
    }
});

router.get('/getuser/:id', (req, res) => {
    if (!req.params.id) {
        res.json({ success: false, message: 'No id provided' });
    } else {
        user.findOne({ email: req.params.id }, (err, user) => {
            if (err) {
                res.json({ success: false, message: 'Not a valid user id' });
            } else {
                res.json(user);
            }
        });
    }
});
router.get('/viewuser/:id', (req, res) => {
    if (!req.params.id) {
        res.json({ success: false, message: 'No id provided' });
    } else {
        user.findOne({ _id: req.params.id }, (err, user) => {
            if (err) {
                res.json({ success: false, message: 'Not a valid user id' });
            } else {
                res.json(user);
            }
        });
    }
});
router.delete("/deluser/:id", (req, res) => {
    var id = req.params.id
    user.remove({ _id: id }, (err) => {
        if (err) {
            console.log("err  in deleting user");
        }
    })
    res.status(200).json({ msg: "Deleted Succesfully" })
})


//pizza
router.get('/getpizza',function (req, res) {
    pizza.find({}, (err, pizza) => {
        if (err) {
            res.json({ success: false, message: err });
        } else {
            if (!pizza) {
                res.json({ success: false, message: 'No pizzas.' });
            } else {
                res.json(pizza);
            }
        }
    })
})

router.post('/addpizza', function (req, res) {
    let note = new pizza(req.body)
    note.save(function (err, note) {
        if (err) {
            return res.status(400).json(err)
        }
        res.status(200).json(note)
    })
})
router.put('/editpizza/:id', (req, res) => {
    if (!req.params.id) {
        res.json({ success: false, message: 'No  id provided' });
    } else {
        pizza.findOne({_id: req.body._id }, (err, pizza) => {
            if (err) {
                res.json({ success: false, message: 'Not a valid id' });
            } else {
                pizza.pizzaname = req.body.pizzaname;
                pizza.pizzasize = req.body.pizzasize;
                pizza.pizzaprice = req.body.pizzaprice;
                pizza.pizzaimage = req.body.pizzaimage;
                pizza.save((err) => {
                    if (err) {
                        res.json({ success: false, message: err });
                    } else {
                        res.json({ success: true, message: 'pizza Updated' });
                    }
                });
            }
        });
    }
});


router.delete("/deletepizza/:id", (req, res) => {
    var id = req.params.id
    console.log(req.params.id);
    pizza.remove({ _id: id }, (err) => {
        if (err) {
            console.log("err  in pizza delete by admin");
        }
    })
    res.status(200).json({ msg: "yes deleted pizza by admin" })
})



//feedback

router.get('/getfb', function (req, res) {
    feedback.find({}, (err, feedback) => {
        if (err) {
            res.json({ success: false, message: err });
        } else {
            if (!feedback) {
                res.json({ success: false, message: 'No pizzas.' });
            } else {
                res.json(feedback);
            }
        }
    })
})
router.post('/postfb', function (req, res) {
    let note = new feedback(req.body)
    note.save(function (err, note) {
        if (err) {
            return res.status(400).json(err)
        }
        res.status(200).json(note)
    })
})
router.delete("/delfb/:id", (req, res) => {
    var id = req.params.id
    console.log(req.params.id);
    feedback.remove({ _id: id }, (err) => {
        if (err) {
            console.log("err  in feedback delete by admin");
        }
    })
    res.status(200).json({ msg: "yes deleted feedback by admin" })
})


//user cart
router.post('/addcart', function (req, res) {
    let note = new cart(req.body)
    note.save(function (err, note) {
        if (err) {
            return res.status(400).json(err)
        }
        res.status(200).json(note)
    })
})
router.get('/getcart/', function (req, res) {
    cart.find({}, (err, cart) => {
        if (err) {
            res.json({ success: false, message: err });
        } else {
            if (!cart) {
                res.json({ success: false, message: 'cart Empty.' });
            } else {
                res.json(cart);
            }
        }
    })
})
router.get('/getcart/:id', (req, res) => {
    if (!req.params.id) {
        res.json({ success: false, message: 'No userid provided' });
    } else {
        cart.find({ userid: req.params.id }, (err, cart) => {
            if (err) {
                res.json({ success: false, message: 'Not a valid userid id' });
            } else {
                res.json(cart);
            }
        });
    }
});
router.delete("/delcart/:id", (req, res) => {
    var id = req.params.id
    console.log(req.params.id);
    cart.remove({ _id: id }, (err) => {
        if (err) {
            console.log("err  in pizza delete from cart");
        }
    })
    res.status(200).json({ msg: "yes deleted pizza from cart" })
})
router.delete("/delcarts/:id", (req, res) => {
    var id = req.params.id
    cart.remove({ userid: id }, (err) => {
        if (err) {
            console.log("err  in deleting cart");
        }
    })
    res.status(200).json({ msg: "cart is Empty" })
})


//orders

router.post('/addorder', function (req, res) {
    let note = new order(req.body)
    note.save(function (err, note) {
        if (err) {
            return res.status(400).json(err)
        }
        res.status(200).json(note)
    })
})
router.get('/getorder', function (req, res) {
    order.find({}, (err, order) => {
        if (err) {
            res.json({ success: false, message: err });
        } else {
            if (!order) {
                res.json({ success: false, message: 'No Orders' });
            } else {
                res.json(order);
            }
        }
    })
})
router.get('/getorderbyid/:id', (req, res) => {
    if (!req.params.id) {
        res.json({ success: false, message: 'No id provided' });
    } else {
        order.find({whichuser: req.params.id }, (err, order) => {
            if (err) {
                res.json({ success: false, message: 'Not a valid id id' });
            } else {
                res.json(order);
            }
        });
    }
});
router.delete("/delorder/:id", (req, res) => {
    var id = req.params.id
    console.log(req.params.id);
    order.remove({ _id: id }, (err) => {
        if (err) {
            console.log("err  in order delete");
        }
    })
    res.status(200).json({ msg: "yes deleted order" })
})
module.exports = router;