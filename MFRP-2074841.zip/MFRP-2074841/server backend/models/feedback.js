var mongoose = require('mongoose')
var feedbackSchema = mongoose.Schema({
    whichuser: {
        type: String,
    },
    email: {
        type: String,      
    },
    name: {
        type: String,
      
    },
    msg: {
        type: String,
    }
})
module.exports = mongoose.model('feedback',feedbackSchema)